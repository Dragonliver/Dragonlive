<?php

namespace XF\Api\Result;

interface ResultInterface
{
	public function render();
}